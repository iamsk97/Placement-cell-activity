var question_description=[];
var question_details=[];
question_description=JSON.parse(localStorage.question_descriptions);
if(!localStorage.question_details)
{
	localStorage.question_details=JSON.stringify([]);
}
question_details=JSON.parse(localStorage.question_details);

function delete_it(elementer)
{
	for(var i=0;i<question_description.length;i++)
	{
		if(question_description[i].question_vid==Number(elementer.parentNode.childNodes[0].innerHTML))
		{
			question_description.splice(i,1);
		}
	}
	for(var i=0;i<question_details.length;i++)
	{
		if(question_details[i].question_vid==Number(elementer.parentNode.childNodes[0].innerHTML))
		{
			question_details.splice(i,1);
			i--;
		}
	}
	window.alert(question_description.length);
	window.alert(question_details.length);
	elementer.parentNode.parentNode.removeChild(elementer.parentNode);
	localStorage.question_descriptions=JSON.stringify(question_description);
	localStorage.question_details=JSON.stringify(question_details);
}
	var x=document.getElementById("product_display");

	var diver=document.createElement("div");
	diver.setAttribute("style"," height:10%;margin:4px;padding:4px;");

	var lab1=document.createElement("label");
	lab1.setAttribute("style"," height:10%;margin:4px;width:25%;padding:4px;");
	var lab1_text=document.createTextNode("S_No");
	lab1.appendChild(lab1_text);
	diver.appendChild(lab1);
	diver.innerHTML+='&emsp;';

	var lab2=document.createElement("label");
	lab2.setAttribute("style"," height:10%;margin:4px;width:25%;padding:4px;");
	var lab2_text=document.createTextNode("Name Of Student");
	lab2.appendChild(lab2_text);
	diver.appendChild(lab2);
	diver.innerHTML+='&emsp;';

	var lab3=document.createElement("label");
	lab3.setAttribute("style"," height:10%;margin:4px;width:25%;padding:4px;");
	var lab3_text=document.createTextNode("Type");
	lab3.appendChild(lab3_text);
	diver.appendChild(lab3);
	diver.innerHTML+='&emsp;';

	var lab4=document.createElement("label");
	lab4.setAttribute("style"," height:10%;margin:4px;width:25%;padding:4px;");
	var lab4_text=document.createTextNode("CGPA");
	lab4.appendChild(lab4_text);
	diver.appendChild(lab4);
	diver.innerHTML+='&emsp;';

	var lab5=document.createElement("label");
	lab5.setAttribute("style"," height:10%;margin:4px;width:25%;padding:4px;");
	var lab5_text=document.createTextNode("Description");
	lab5.appendChild(lab5_text);
	diver.appendChild(lab5);

	x.appendChild(diver);

for(var a=0;a<question_description.length;a++)
{
	var diver=document.createElement("div");
	diver.setAttribute("style","border:1px solid grey; height:05%;margin:4px;padding:4px;");

	var lab1=document.createElement("label");
	lab1.setAttribute("style"," height:10%;margin:4px;width:15%;padding:4px;");
	var lab1_text=document.createTextNode(question_description[a].question_vid);
	lab1.appendChild(lab1_text);
	diver.appendChild(lab1);
	diver.innerHTML+='&emsp;&emsp;&emsp;&emsp;';

	var lab2=document.createElement("label");
	lab2.setAttribute("style"," height:10%;margin:4px;width:15%;padding:4px;");
	var lab2_text=document.createTextNode(question_description[a].question_title);
	lab2.appendChild(lab2_text);
	diver.appendChild(lab2);
	diver.innerHTML+='&emsp;&emsp;&emsp;&emsp;';

	var lab3=document.createElement("label");
	lab3.setAttribute("style"," height:10%;margin:4px;width:15%;padding:4px;");
	var lab3_text=document.createTextNode(question_description[a].question_type);
	lab3.appendChild(lab3_text);
	diver.appendChild(lab3);
	diver.innerHTML+='&emsp;&emsp;&emsp;&emsp;';

	var lab4=document.createElement("label");
	lab4.setAttribute("style"," height:10%;margin:4px;width:15%;padding:4px;");
	var lab4_text=document.createTextNode(question_description[a].question_score);
	lab4.appendChild(lab4_text);
	diver.appendChild(lab4);
	diver.innerHTML+='&emsp;&emsp;&emsp;&emsp;';

	var lab5=document.createElement("label");
	lab5.setAttribute("style"," height:10%;margin:4px;width:15%;padding:4px;");
	var lab5_text=document.createTextNode(question_description[a].question_description);
	lab5.appendChild(lab5_text);
	diver.appendChild(lab5);

	var but1=document.createElement("button");
	var but1_text=document.createTextNode("Delete");
	but1.setAttribute("onclick","delete_it(this)");
	but1.appendChild(but1_text);
	diver.appendChild(but1);

	x.appendChild(diver);
}
