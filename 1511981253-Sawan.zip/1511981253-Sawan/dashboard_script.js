var product_bt=document.getElementById("product_button");
var user_bt=document.getElementById("user_button");
var login_info=[];
if((!sessionStorage.question_login_info)||(sessionStorage.question_login_info==""))
{
	window.location="login.html";
}
else
{
	login_info=JSON.parse(sessionStorage.question_login_info);
}
var welcome_small_div=document.createElement("div");
welcome_small_div.setAttribute("style","float:right;");
var welcome_name=document.createElement("label");
var welcome_name_text=document.createTextNode(login_info[0].username);
welcome_name.appendChild(welcome_name_text);
welcome_small_div.appendChild(welcome_name);
var logout_button=document.createElement("button");
var logout_button_text=document.createTextNode("logout");
logout_button.setAttribute("onclick","logging_out(this)");
logout_button.appendChild(logout_button_text);
welcome_small_div.appendChild(logout_button);
document.getElementById("welcome").appendChild(welcome_small_div);

function logging_out()
{
	sessionStorage.question_login_info="";
	window.location="login.html";
}
product_bt.addEventListener("click",function(event)
{
		var mid=document.getElementById("mid_div_display");
		mid.innerHTML="";
		var new_div=document.createElement("div");
		new_div.setAttribute("style","border:2px solid grey; height:05%;margin:4px;padding:4px;");
		var button1=document.createElement("button");
		var button1_text=document.createTextNode("Display All Students");
		button1.setAttribute("onclick","display_questions()");
		button1.appendChild(button1_text);
		new_div.appendChild(button1);
		new_div.innerHTML+='&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;';
		
		var button2=document.createElement("button");
		button2.setAttribute("onclick","add_questions()");
		var button2_text=document.createTextNode("Add Students");
		button2.appendChild(button2_text);
		new_div.appendChild(button2);
		
		mid.appendChild(new_div);
		
		var new2_div=document.createElement("div");
		new2_div.setAttribute("style","border:2px solid grey;height:90%;width:100%;");
		new2_div.setAttribute("id","new_mid_display");
		mid.appendChild(new2_div);
});
function display_questions()
{
	document.getElementById("new_mid_display").innerHTML="";
	document.getElementById("new_mid_display").innerHTML='<object type="text/html" data="displayquestion.html" width="100%" height="400" ></object>';
}
function add_questions()
{
	document.getElementById("new_mid_display").innerHTML="";
	document.getElementById("new_mid_display").innerHTML='<object type="text/html" data="add_questions.html"width="100%"height="100%"></object>';
}