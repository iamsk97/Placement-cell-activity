var Email=document.getElementById("user_name_text");
var Password=document.getElementById("password_text");
var Login1=document.getElementById("login_button");
var question_login_info=[];
var flag=0;
Login1.addEventListener("click",function(event){
	event.preventDefault();
	if(Email.value=="admin@gmail.com")
		{
			flag=1;
			if(Password.value=="Temp123!")
			{
				window.alert("Admin Logged In");
				var obj=new Object;
				obj.username="admin@gmail.com";
				obj.user_password="Temp123!";
				question_login_info.push(obj);
				sessionStorage.question_login_info = JSON.stringify(question_login_info);
				window.location="dashboard.html";
			}
			else
			{
				window.alert("Password is incoorect");
				Password.value="";
			}
		}
	if(flag==0)
	{
		window.alert("username is incorrect ");
		Password.value="";
		Email.value="";
	}
});
