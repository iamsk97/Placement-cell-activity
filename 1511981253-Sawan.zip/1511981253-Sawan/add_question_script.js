var qt=document.getElementById("question_type");
var work_spc=document.getElementById("workspace");
var question_descriptions=[];
var question_details=[];
var vid=0;
var flag=0;
var flag2=0;
if(!localStorage.vid)
{
	localStorage.vid=JSON.stringify([]);
}
vid=JSON.parse(localStorage.vid);
if(!localStorage.question_descriptions)
{
	localStorage.question_descriptions=JSON.stringify([]);
}
question_descriptions=JSON.parse(localStorage.question_descriptions);
if(!localStorage.question_details)
{
	localStorage.question_details=JSON.stringify([]);
}
question_details=JSON.parse(localStorage.question_details);
function final_submission()
{
	var obj1=new Object();
	obj1.question_vid=Number(vid);
	obj1.question_type=document.getElementById("question_type").value;
	obj1.question_score=document.getElementById("score_input").value;
	obj1.question_title=document.getElementById("title_input").value;
	obj1.question_description=document.getElementById("description_text_area").value;
	
	question_descriptions.push(obj1);
	//window.alert(question_descriptions[0].question_type);
	var x=document.getElementsByClassName("option_list");
	var y=document.getElementsByClassName("checklist");

	for(var i=0;i<x.length;i++)
	{
		var obj3=new Object();
		obj3.question_vid=vid;
		obj3.question_option=x[i].value;

		if((flag2==0)&&(y[i].checked))
		{
			obj3.question_checklist=1;
			flag2=1;
		}
		else
		{
			obj3.question_checklist=0;
		}
		question_details.push(obj3);
	}

	vid=Number(vid)+1;
	localStorage.question_descriptions=JSON.stringify(question_descriptions);
	localStorage.question_details=JSON.stringify(question_details);
	localStorage.vid=JSON.stringify(vid);             
	
	
	
	
	
	
	window.alert("Data Added Successfully");
	document.getElementById("question_type").value=qt.value;
	document.getElementById("score_input").value=" ";
	document.getElementById("title_input").value=" ";
	document.getElementById("description_text_area").value=" ";
	
	
	
	
	
	
	
}
function delete_option(elementer)
{
	elementer.parentNode.parentNode.removeChild(elementer.parentNode);
}
function option_checker(elementer)
{
	if((elementer.checked)&&(flag==0))
	{
		flag=1;
	}
	else if((elementer.checked)&&(flag==1))
	{
		window.alert("uncheck the checked option first");
		elementer.checked=false;
	}
	else if(!(elementer.checked)&&(flag==1))
	{
		flag=0;
	}
}
function create_more_options()
{
		var opt2=document.createElement("div");
		opt2.setAttribute("id","second_option_div");
		var opt2_input=document.createElement("input");
		opt2_input.setAttribute("type","text");
		opt2_input.setAttribute("class","option_list");
		opt2.appendChild(opt2_input);
		var opt2_check=document.createElement("input");
		opt2_check.setAttribute("type","checkbox");
		opt2_check.setAttribute("class","checklist");
		opt2_check.setAttribute("onchange","option_checker(this)");
		opt2.appendChild(opt2_check);
		opt2.appendChild("&nbsp");
		var but3=document.createElement("button");
		
		var but3_text=document.createTextNode("delete");
		but3.setAttribute("onclick","delete_option(this)");
		but3.appendChild(but3_text);
		opt2.appendChild(but3);
		document.getElementById("option_div").appendChild(opt2);

}
function check_it(elementer)
{
		if(elementer.checked)
		{
			document.getElementById("negetive_hider").style.visibility="visible";
			//elementer.checked=false;
		}
		else
		{
			document.getElementById("negetive_hider").style.visibility="hidden";
			//elementer.checked=false;
		}
}
qt.addEventListener("change",function(event){
	if(qt.value=="Passes")
	{

		var title_lab=document.createElement("label");
		var title_lab_text=document.createTextNode("Name of Student");
		title_lab.appendChild(title_lab_text);
		work_spc.appendChild(title_lab);

		var title_input=document.createElement("input");
		title_input.setAttribute("type","text");
		title_input.setAttribute("id","title_input");
		work_spc.innerHTML+='&emsp;';
		work_spc.appendChild(title_input);
		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);

		var score_lab=document.createElement("label");
		var score_lab_text=document.createTextNode("CGPA");
		score_lab.appendChild(score_lab_text);
		work_spc.appendChild(score_lab);

		var score_input=document.createElement("input");
		score_input.setAttribute("type","number");
		score_input.setAttribute("id","score_input");
		work_spc.innerHTML+='&nbsp;';
		work_spc.appendChild(score_input);
		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);

		/*var negetive_div=document.createElement("div");
		negetive_div.setAttribute("id","negetive_div");

		var negetive_marking=document.createElement("label");
		var negetive_marking_text=document.createTextNode("Enable Negetive Marking");
		negetive_marking.appendChild(negetive_marking_text);
		negetive_div.appendChild(negetive_marking);
		negetive_div.innerHTML+='&emsp;';

		var checker=document.createElement("input");
		checker.setAttribute("type","checkbox");
		checker.setAttribute("id","checker");
		checker.setAttribute("onchange","check_it(this)");
		negetive_div.appendChild(checker);
		work_spc.appendChild(negetive_div);*/

		/*var negetive_hider=document.createElement("div");
		negetive_hider.setAttribute("id","negetive_hider");
		negetive_hider.style.visibility="hidden";
		var negetive_value=document.createElement("label");
		var negetive_value_text=document.createTextNode("Negetive score value");
		negetive_value.appendChild(negetive_value_text);
		document.getElementById("negetive_div").appendChild(negetive_value);
		document.getElementById("negetive_div").innerHTML+='&emsp;';

		var title_input=document.createElement("input");
		title_input.setAttribute("type","number");
		title_input.setAttribute("id","negetive_input");
		negetive_hider.appendChild(title_input);
		document.getElementById("negetive_div").appendChild(negetive_hider);*/

		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);

		var description_lab=document.createElement("label");
		var description_lab_text=document.createTextNode("Description");
		description_lab.appendChild(description_lab_text);
		work_spc.appendChild(description_lab);
		work_spc.innerHTML+='&nbsp';

		var description_text_area=document.createElement("textarea");
		description_text_area.setAttribute("id","description_text_area");
		work_spc.appendChild(description_text_area);
		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);

		/*var option_div=document.createElement("div");
		option_div.setAttribute("id","option_div");

		var option_lab=document.createElement("label");
		var option_lab_text=document.createTextNode("options");
		option_lab.appendChild(option_lab_text);
		option_div.appendChild(option_lab);
		var brr=document.createElement("br");

		var opt1=document.createElement("div");
		opt1.setAttribute("id","first_option_div");
		var opt1_input=document.createElement("input");
		opt1_input.setAttribute("type","text");
		opt1_input.setAttribute("class","option_list");
		opt1.appendChild(opt1_input);
		var opt1_check=document.createElement("input");
		opt1_check.setAttribute("type","checkbox");
		opt1_check.setAttribute("class","checklist");
		opt1_check.setAttribute("onchange","option_checker(this)");
		opt1.appendChild(opt1_check);

		option_div.appendChild(opt1);

		var opt3=document.createElement("div");
		opt3.setAttribute("id","second_option_div");
		var opt3_input=document.createElement("input");
		opt3_input.setAttribute("type","text");
		opt3_input.setAttribute("class","option_list");
		opt3.appendChild(opt3_input);

		var opt3_check=document.createElement("input");
		opt3_check.setAttribute("type","checkbox");
		opt3_check.setAttribute("class","checklist");
		opt3_check.setAttribute("onchange","option_checker(this)");
		opt3.appendChild(opt3_check);

		option_div.appendChild(opt3);

		work_spc.appendChild(option_div);

		var but6=document.createElement("button");
		var but6_text=document.createTextNode("Add More");
		but6.setAttribute("onclick","create_more_options()");
		but6.appendChild(but6_text);
		work_spc.appendChild(but6);

		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);*/

		var buts=document.createElement("button");
		var buts_text=document.createTextNode("submit");
		buts.setAttribute("onclick","final_submission()");
		buts.appendChild(buts_text);
		work_spc.appendChild(buts);

	}
	/*else if(qt.value=="coding")

	{
		var title_lab=document.createElement("label");
		var title_lab_text=document.createTextNode("Question Title");
		title_lab.appendChild(title_lab_text);
		work_spc.appendChild(title_lab);

		var title_input=document.createElement("input");
		title_input.setAttribute("type","text");
		title_input.setAttribute("id","title_input");
		work_spc.innerHTML+='&nbsp;';
		work_spc.appendChild(title_input);
		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);


		var keyword_lab=document.createElement("label");
		var keyword_text=document.createTextNode("keyword");
		keyword_lab.appendChild(keyword_text);
		work_spc.appendChild(keyword_lab);

		var keyword_input=document.createElement("input");
		keyword_input.setAttribute("type","text");
		keyword_input.setAttribute("id","keyword_input");
		work_spc.innerHTML+='&nbsp;';
		work_spc.appendChild(keyword_input);
		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);


var description_lab=document.createElement("label");
		var description_lab_text=document.createTextNode("Description");
		description_lab.appendChild(description_lab_text);
		work_spc.appendChild(description_lab);
		work_spc.innerHTML+='&nbsp;';

		var description_text_area=document.createElement("textarea");
		description_text_area.setAttribute("id","description_text_area");
		work_spc.appendChild(description_text_area);
		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);


		var select=document.createElement('select');
  select.setAttribute('id','lang');

  var option1=document.createElement('option');
  option1.innerHTML='C';
  var option2=document.createElement('option');
  option2.innerHTML='C++';
  var option3=document.createElement('option');
  option3.innerHTML='Java';
  var option4=document.createElement('option');
  option4.innerHTML='Python';
  select.appendChild(option1);
  select.appendChild(option2);
  select.appendChild(option3);
  select.appendChild(option4);
  work_spc.appendChild(select);



		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);

		var option_div=document.createElement("div");
		option_div.setAttribute("id","option_div");

		var option_lab=document.createElement("label");
		var option_lab_text=document.createTextNode("Testcases");
		option_lab.appendChild(option_lab_text);
		option_div.appendChild(option_lab);
		var brr=document.createElement("br");

		var opt5=document.createElement("div");
		opt5.setAttribute("id","first_option_div");
		var Input=document.createElement('input');
		Input.setAttribute("type","text");
		Input.setAttribute("style","margin-left: 80px");
		Input.setAttribute('placeholder','Input');
		Input.setAttribute("class","option_list");
		opt5.appendChild(Input);

		var Output=document.createElement('input');
		Output.setAttribute("type","text");
		Output.setAttribute("style","margin-left: 10px");
		Output.setAttribute('placeholder','Expected Output');
		Output.setAttribute("class","option_list");
		opt5.appendChild(Output);

		var Score=document.createElement('input');
		Score.setAttribute("type","number");
		Score.setAttribute('placeholder','Score');
		Score.setAttribute("style","margin-left: 10px");
		Score.setAttribute("class","option_list");
		opt5.appendChild(Score);

		option_div.appendChild(opt5);
		work_spc.appendChild(option_div);




		var but1=document.createElement("button");
		var but1_text=document.createTextNode("Add More");
		but1.appendChild(but1_text);
		but1.setAttribute("onclick","create_more_options()");
		work_spc.appendChild(but1);

		var but4=document.createElement("button");
		var but4_text=document.createTextNode("Submit");
		//but4.setAttribute("onclick","final_submission()");
		but4.appendChild(but4_text);
		but4.addEventListener("click",function(event){
			final_submission();

		});
		work_spc.appendChild(but4);

		var brr=document.createElement("br");
		work_spc.appendChild(brr);
		brr=document.createElement("br");
		work_spc.appendChild(brr);

		

	

		//document.getElementById("workspace").innerHTML="";
	}
	else if(qt.value=="subjective")
	{
		document.getElementById("workspace").innerHTML="";
	}*/
});
